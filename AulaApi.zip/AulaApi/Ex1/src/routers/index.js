import express from "express.js";
import post from "./postsRoutes.js";
import app from ".../app.js";

const routes = (app) => {
};